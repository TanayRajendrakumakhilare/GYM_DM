# gym-management
Gym Management System provides an easy to use interface for the users and a database for the admin to maintain the records of gym members.

## Screenshots
### Login Page
![login page](/images/login.png)
### Members registration page
![Members registration page](/images/member.png)
